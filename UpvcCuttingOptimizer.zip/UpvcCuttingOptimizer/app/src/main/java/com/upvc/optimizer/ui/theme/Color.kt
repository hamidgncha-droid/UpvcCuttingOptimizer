package com.upvc.optimizer.ui.theme

import androidx.compose.ui.graphics.Color

// رنگ‌های اصلی مدرن
val Primary = Color(0xFF0D47A1)          // آبی تیره حرفه‌ای
val OnPrimary = Color(0xFFFFFFFF)
val PrimaryContainer = Color(0xFFBBDEFB)
val OnPrimaryContainer = Color(0xFF002171)

val Secondary = Color(0xFF00695C)        // سبز زمردی
val OnSecondary = Color(0xFFFFFFFF)
val SecondaryContainer = Color(0xFFB2DFDB)
val OnSecondaryContainer = Color(0xFF00251A)

val Tertiary = Color(0xFFE65100)         // نارنجی برای تأکید
val OnTertiary = Color(0xFFFFFFFF)

val Error = Color(0xFFB00020)
val OnError = Color(0xFFFFFFFF)

val BackgroundLight = Color(0xFFF8FAFC)
val OnBackgroundLight = Color(0xFF0F172A)
val SurfaceLight = Color(0xFFFFFFFF)
val OnSurfaceLight = Color(0xFF0F172A)

val BackgroundDark = Color(0xFF0F172A)
val OnBackgroundDark = Color(0xFFF1F5F9)
val SurfaceDark = Color(0xFF1E293B)
val OnSurfaceDark = Color(0xFFF1F5F9)

// رنگ‌های وضعیت ضایعات
val WasteGood = Color(0xFF2E7D32)        // سبز - ضایعات کم
val WasteMedium = Color(0xFFF9A825)      // زرد - متوسط
val WasteBad = Color(0xFFC62828)         // قرمز - زیاد
