package com.upvc.optimizer.ui.navigation

import androidx.compose.runtime.Composable
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.upvc.optimizer.ui.screens.home.HomeScreen
import com.upvc.optimizer.ui.screens.input.InputScreen
import com.upvc.optimizer.ui.screens.result.ResultScreen

object Routes {
    const val HOME = "home"
    const val INPUT = "input"
    const val RESULT = "result"
}

@Composable
fun AppNavigation() {
    val navController = rememberNavController()

    NavHost(
        navController = navController,
        startDestination = Routes.HOME
    ) {
        composable(Routes.HOME) {
            HomeScreen(
                onNewProject = { navController.navigate(Routes.INPUT) },
                onOpenProject = { /* بعداً پیاده‌سازی می‌شود */ }
            )
        }

        composable(Routes.INPUT) {
            InputScreen(
                onBack = { navController.popBackStack() },
                onCalculate = { navController.navigate(Routes.RESULT) }
            )
        }

        composable(Routes.RESULT) {
            ResultScreen(
                onBack = { navController.popBackStack() },
                onHome = {
                    navController.navigate(Routes.HOME) {
                        popUpTo(Routes.HOME) { inclusive = true }
                    }
                }
            )
        }
    }
}
