package com.upvc.optimizer

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class UpvcApp : Application()
