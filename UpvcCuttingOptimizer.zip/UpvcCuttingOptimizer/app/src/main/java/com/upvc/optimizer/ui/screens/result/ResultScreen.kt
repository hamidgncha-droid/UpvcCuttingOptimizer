package com.upvc.optimizer.ui.screens.result

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.Save
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.upvc.optimizer.ui.theme.WasteBad
import com.upvc.optimizer.ui.theme.WasteGood
import com.upvc.optimizer.ui.theme.WasteMedium

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ResultScreen(
    onBack: () -> Unit,
    onHome: () -> Unit
) {
    // داده‌های نمونه برای نمایش (بعداً از ViewModel می‌آید)
    val sampleWastePercent = 8.4
    val sampleTotalBars = 12
    val wasteColor = when {
        sampleWastePercent < 10 -> WasteGood
        sampleWastePercent < 20 -> WasteMedium
        else -> WasteBad
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("نتایج بهینه‌سازی") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "بازگشت")
                    }
                },
                actions = {
                    IconButton(onClick = { /* ذخیره */ }) {
                        Icon(Icons.Default.Save, contentDescription = "ذخیره")
                    }
                    IconButton(onClick = { /* PDF */ }) {
                        Icon(Icons.Default.PictureAsPdf, contentDescription = "خروجی PDF")
                    }
                    IconButton(onClick = onHome) {
                        Icon(Icons.Default.Home, contentDescription = "خانه")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primary,
                    titleContentColor = MaterialTheme.colorScheme.onPrimary,
                    navigationIconContentColor = MaterialTheme.colorScheme.onPrimary,
                    actionIconContentColor = MaterialTheme.colorScheme.onPrimary
                )
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
            contentPadding = PaddingValues(vertical = 16.dp)
        ) {
            // کارت خلاصه
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.primaryContainer
                    )
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(20.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = "خلاصه نتایج",
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold
                        )

                        Spacer(modifier = Modifier.height(20.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceEvenly
                        ) {
                            SummaryItem(
                                title = "تعداد شاخه",
                                value = "$sampleTotalBars",
                                unit = "عدد"
                            )
                            SummaryItem(
                                title = "ضایعات",
                                value = String.format("%.1f", sampleWastePercent),
                                unit = "%",
                                valueColor = wasteColor
                            )
                        }
                    }
                }
            }

            item {
                Text(
                    text = "الگوهای برش",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
            }

            // الگوهای نمونه
            items(3) { index ->
                PatternCard(
                    patternNumber = index + 1,
                    usageCount = listOf(5, 4, 3)[index],
                    remaining = listOf(12.5, 8.0, 22.0)[index]
                )
            }
        }
    }
}

@Composable
private fun SummaryItem(
    title: String,
    value: String,
    unit: String,
    valueColor: Color = MaterialTheme.colorScheme.onPrimaryContainer
) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(
            text = title,
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.8f)
        )
        Spacer(modifier = Modifier.height(4.dp))
        Row(verticalAlignment = Alignment.Bottom) {
            Text(
                text = value,
                style = MaterialTheme.typography.headlineMedium,
                fontWeight = FontWeight.Bold,
                color = valueColor
            )
            Spacer(modifier = Modifier.width(4.dp))
            Text(
                text = unit,
                style = MaterialTheme.typography.bodyMedium,
                color = valueColor.copy(alpha = 0.8f)
            )
        }
    }
}

@Composable
private fun PatternCard(
    patternNumber: Int,
    usageCount: Int,
    remaining: Double
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "الگوی $patternNumber",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.SemiBold
                )
                AssistChip(
                    onClick = {},
                    label = { Text("$usageCount شاخه") }
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            // نوار گرافیکی ساده
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(32.dp)
                    .clip(RoundedCornerShape(8.dp))
            ) {
                Box(
                    modifier = Modifier
                        .weight(3f)
                        .fillMaxHeight()
                        .background(Color(0xFF1976D2))
                )
                Box(
                    modifier = Modifier
                        .weight(2f)
                        .fillMaxHeight()
                        .background(Color(0xFF388E3C))
                )
                Box(
                    modifier = Modifier
                        .weight(1.5f)
                        .fillMaxHeight()
                        .background(Color(0xFFF57C00))
                )
                Box(
                    modifier = Modifier
                        .weight(0.8f)
                        .fillMaxHeight()
                        .background(Color(0xFFBDBDBD))
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = "ضایعات این الگو: $remaining سانتی‌متر",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
            )
        }
    }
}
