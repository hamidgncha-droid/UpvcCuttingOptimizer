package com.upvc.optimizer.domain.model

import androidx.compose.ui.graphics.Color
import java.util.UUID

/**
 * نوع پروفیل (مثلاً قاب، لنگه، میانی و ...)
 */
data class ProfileType(
    val id: String = UUID.randomUUID().toString(),
    val name: String,
    val colorValue: Long = 0xFF1976D2
) {
    val color: Color
        get() = Color(colorValue)
}

/**
 * یک قطعه مورد نیاز
 */
data class Piece(
    val id: String = UUID.randomUUID().toString(),
    val profileTypeId: String,
    val lengthCm: Double,
    val quantity: Int
)

/**
 * یک قطعه داخل الگوی برش (همراه با تعداد تکرار در همان الگو)
 */
data class PatternItem(
    val piece: Piece,
    val countInPattern: Int,
    val profileName: String,
    val colorValue: Long
)

/**
 * یک الگوی برش
 */
data class CuttingPattern(
    val id: String = UUID.randomUUID().toString(),
    val items: List<PatternItem>,
    val remainingLengthCm: Double,
    val usageCount: Int                 // چند شاخه با این الگو برش می‌خورد
) {
    val usedLengthCm: Double
        get() = items.sumOf { it.piece.lengthCm * it.countInPattern }
}

/**
 * نتیجه کامل بهینه‌سازی
 */
data class OptimizationResult(
    val totalBars: Int,
    val totalWastePercent: Double,
    val totalUsedLengthCm: Double,
    val totalRawLengthCm: Double,
    val patterns: List<CuttingPattern>,
    val stockLengthCm: Double,
    val kerfCm: Double
)

/**
 * پروژه ذخیره شده
 */
data class Project(
    val id: String = UUID.randomUUID().toString(),
    val name: String,
    val createdAt: Long = System.currentTimeMillis(),
    val stockLengthCm: Double = 600.0,
    val kerfCm: Double = 0.5,
    val profileTypes: List<ProfileType> = emptyList(),
    val pieces: List<Piece> = emptyList(),
    val result: OptimizationResult? = null
)
