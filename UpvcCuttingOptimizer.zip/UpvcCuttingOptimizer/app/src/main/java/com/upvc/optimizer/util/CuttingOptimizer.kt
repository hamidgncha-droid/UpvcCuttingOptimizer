package com.upvc.optimizer.util

import com.upvc.optimizer.domain.model.*
import kotlin.math.ceil
import kotlin.math.max

/**
 * الگوریتم بهینه‌سازی برش یک‌بعدی برای پروفیل‌های UPVC
 *
 * از ترکیب First Fit Decreasing (FFD) و تولید الگوهای تکراری استفاده می‌کند.
 * ضخامت تیغه (kerf) در هر برش در نظر گرفته می‌شود.
 */
class CuttingOptimizer {

    /**
     * اجرای بهینه‌سازی
     *
     * @param pieces لیست قطعات مورد نیاز
     * @param profileTypes انواع پروفیل (برای نام و رنگ)
     * @param stockLengthCm طول شاخه خام (پیش‌فرض ۶۰۰ سانتی‌متر)
     * @param kerfCm ضخامت تیغه اره (پیش‌فرض ۰٫۵ سانتی‌متر = ۵ میلی‌متر)
     */
    fun optimize(
        pieces: List<Piece>,
        profileTypes: List<ProfileType>,
        stockLengthCm: Double = 600.0,
        kerfCm: Double = 0.5
    ): OptimizationResult {

        if (pieces.isEmpty()) {
            return OptimizationResult(
                totalBars = 0,
                totalWastePercent = 0.0,
                totalUsedLengthCm = 0.0,
                totalRawLengthCm = 0.0,
                patterns = emptyList(),
                stockLengthCm = stockLengthCm,
                kerfCm = kerfCm
            )
        }

        // ساخت نقشه نام و رنگ پروفیل‌ها
        val profileMap = profileTypes.associateBy { it.id }

        // باز کردن قطعات به لیست تخت (هر قطعه به تعداد quantity)
        val allItems = mutableListOf<ExpandedPiece>()
        pieces.forEach { piece ->
            val profile = profileMap[piece.profileTypeId]
            repeat(piece.quantity) {
                allItems.add(
                    ExpandedPiece(
                        originalPiece = piece,
                        lengthCm = piece.lengthCm,
                        profileName = profile?.name ?: "نامشخص",
                        colorValue = profile?.colorValue ?: 0xFF1976D2
                    )
                )
            }
        }

        // مرتب‌سازی نزولی (First Fit Decreasing)
        allItems.sortByDescending { it.lengthCm }

        // لیست شاخه‌های استفاده‌شده
        val bars = mutableListOf<Bar>()

        for (item in allItems) {
            var placed = false

            // سعی می‌کنیم در شاخه‌های موجود جا بدهیم
            for (bar in bars) {
                if (bar.canFit(item.lengthCm, kerfCm, stockLengthCm)) {
                    bar.add(item, kerfCm)
                    placed = true
                    break
                }
            }

            // اگر جا نشد، شاخه جدید باز می‌کنیم
            if (!placed) {
                val newBar = Bar()
                newBar.add(item, kerfCm)
                bars.add(newBar)
            }
        }

        // تبدیل شاخه‌ها به الگوهای تکراری (برای نمایش بهتر)
        val patterns = groupIntoPatterns(bars, stockLengthCm)

        val totalBars = bars.size
        val totalUsedLength = allItems.sumOf { it.lengthCm }
        val totalRawLength = totalBars * stockLengthCm
        val wastePercent = if (totalRawLength > 0) {
            ((totalRawLength - totalUsedLength) / totalRawLength) * 100.0
        } else 0.0

        return OptimizationResult(
            totalBars = totalBars,
            totalWastePercent = wastePercent,
            totalUsedLengthCm = totalUsedLength,
            totalRawLengthCm = totalRawLength,
            patterns = patterns,
            stockLengthCm = stockLengthCm,
            kerfCm = kerfCm
        )
    }

    /**
     * شاخه‌های مشابه را گروه‌بندی می‌کند تا الگوهای تکراری ساخته شود
     */
    private fun groupIntoPatterns(bars: List<Bar>, stockLengthCm: Double): List<CuttingPattern> {
        // کلید الگو بر اساس ترکیب قطعات
        data class PatternKey(val signature: String)

        val groups = mutableMapOf<PatternKey, MutableList<Bar>>()

        for (bar in bars) {
            val signature = bar.items
                .groupBy { it.originalPiece.id }
                .map { (id, list) -> "$id:${list.size}" }
                .sorted()
                .joinToString("|")

            val key = PatternKey(signature)
            groups.getOrPut(key) { mutableListOf() }.add(bar)
        }

        return groups.map { (_, similarBars) ->
            val sample = similarBars.first()
            val items = sample.items
                .groupBy { it.originalPiece.id }
                .map { (_, list) ->
                    val first = list.first()
                    PatternItem(
                        piece = first.originalPiece,
                        countInPattern = list.size,
                        profileName = first.profileName,
                        colorValue = first.colorValue
                    )
                }

            CuttingPattern(
                items = items,
                remainingLengthCm = stockLengthCm - sample.usedLengthWithKerf,
                usageCount = similarBars.size
            )
        }.sortedByDescending { it.usageCount }
    }

    // -------------------- کلاس‌های داخلی --------------------

    private data class ExpandedPiece(
        val originalPiece: Piece,
        val lengthCm: Double,
        val profileName: String,
        val colorValue: Long
    )

    private class Bar {
        val items = mutableListOf<ExpandedPiece>()
        var usedLengthWithKerf = 0.0   // طول مصرف‌شده شامل تیغه‌ها

        fun canFit(lengthCm: Double, kerfCm: Double, stockLengthCm: Double): Boolean {
            val needed = if (items.isEmpty()) {
                lengthCm
            } else {
                lengthCm + kerfCm
            }
            return usedLengthWithKerf + needed <= stockLengthCm + 0.001 // تحمل خطای ممیز شناور
        }

        fun add(item: ExpandedPiece, kerfCm: Double) {
            if (items.isNotEmpty()) {
                usedLengthWithKerf += kerfCm
            }
            usedLengthWithKerf += item.lengthCm
            items.add(item)
        }
    }
}
