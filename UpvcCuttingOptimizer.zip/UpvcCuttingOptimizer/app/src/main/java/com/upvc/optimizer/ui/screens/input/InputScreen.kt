package com.upvc.optimizer.ui.screens.input

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.upvc.optimizer.domain.model.Piece
import com.upvc.optimizer.domain.model.ProfileType

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun InputScreen(
    onBack: () -> Unit,
    onCalculate: () -> Unit
) {
    // حالت‌های موقت (بعداً با ViewModel جایگزین می‌شود)
    var stockLength by remember { mutableStateOf("600") }
    var kerf by remember { mutableStateOf("0.5") }

    var profileTypes by remember {
        mutableStateOf(
            listOf(
                ProfileType(name = "قاب", colorValue = 0xFF1976D2),
                ProfileType(name = "لنگه", colorValue = 0xFF388E3C),
                ProfileType(name = "میانی", colorValue = 0xFFF57C00)
            )
        )
    }

    var pieces by remember { mutableStateOf(listOf<Piece>()) }

    var showAddPieceDialog by remember { mutableStateOf(false) }
    var selectedProfileId by remember { mutableStateOf(profileTypes.firstOrNull()?.id ?: "") }
    var pieceLength by remember { mutableStateOf("") }
    var pieceQuantity by remember { mutableStateOf("1") }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("ورود اطلاعات برش") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "بازگشت")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primary,
                    titleContentColor = MaterialTheme.colorScheme.onPrimary,
                    navigationIconContentColor = MaterialTheme.colorScheme.onPrimary
                )
            )
        },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = onCalculate,
                icon = { Icon(Icons.Default.PlayArrow, contentDescription = null) },
                text = { Text("محاسبه بهینه‌سازی") },
                containerColor = MaterialTheme.colorScheme.secondary
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
            contentPadding = PaddingValues(vertical = 16.dp)
        ) {
            // تنظیمات کلی
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = "تنظیمات کلی",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(12.dp))

                        OutlinedTextField(
                            value = stockLength,
                            onValueChange = { stockLength = it },
                            label = { Text("طول شاخه خام (سانتی‌متر)") },
                            modifier = Modifier.fillMaxWidth(),
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                            singleLine = true
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        OutlinedTextField(
                            value = kerf,
                            onValueChange = { kerf = it },
                            label = { Text("ضخامت تیغه اره (سانتی‌متر)") },
                            modifier = Modifier.fillMaxWidth(),
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                            singleLine = true,
                            supportingText = { Text("۵ میلی‌متر = ۰٫۵ سانتی‌متر") }
                        )
                    }
                }
            }

            // انواع پروفیل
            item {
                Text(
                    text = "انواع پروفیل",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
            }

            items(profileTypes) { profile ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f)
                    )
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(16.dp)
                                .background(
                                    color = profile.color,
                                    shape = RoundedCornerShape(4.dp)
                                )
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        Text(
                            text = profile.name,
                            style = MaterialTheme.typography.bodyLarge,
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }

            // قطعات
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "قطعات مورد نیاز",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    FilledTonalButton(onClick = { showAddPieceDialog = true }) {
                        Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("افزودن")
                    }
                }
            }

            if (pieces.isEmpty()) {
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(24.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "هنوز قطعه‌ای اضافه نشده است",
                                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                            )
                        }
                    }
                }
            } else {
                items(pieces, key = { it.id }) { piece ->
                    val profile = profileTypes.find { it.id == piece.profileTypeId }
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = profile?.name ?: "نامشخص",
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.SemiBold
                                )
                                Text(
                                    text = "${piece.lengthCm} سانتی‌متر × ${piece.quantity} عدد",
                                    style = MaterialTheme.typography.bodyMedium
                                )
                            }
                            IconButton(onClick = {
                                pieces = pieces.filter { it.id != piece.id }
                            }) {
                                Icon(
                                    Icons.Default.Delete,
                                    contentDescription = "حذف",
                                    tint = MaterialTheme.colorScheme.error
                                )
                            }
                        }
                    }
                }
            }

            // فضای خالی برای FAB
            item {
                Spacer(modifier = Modifier.height(80.dp))
            }
        }
    }

    // دیالوگ افزودن قطعه
    if (showAddPieceDialog) {
        AlertDialog(
            onDismissRequest = { showAddPieceDialog = false },
            title = { Text("افزودن قطعه جدید") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    // انتخاب نوع پروفیل
                    Text("نوع پروفیل:")
                    profileTypes.forEach { profile ->
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            RadioButton(
                                selected = selectedProfileId == profile.id,
                                onClick = { selectedProfileId = profile.id }
                            )
                            Text(profile.name)
                        }
                    }

                    OutlinedTextField(
                        value = pieceLength,
                        onValueChange = { pieceLength = it },
                        label = { Text("طول (سانتی‌متر)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    OutlinedTextField(
                        value = pieceQuantity,
                        onValueChange = { pieceQuantity = it },
                        label = { Text("تعداد") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        val length = pieceLength.toDoubleOrNull()
                        val qty = pieceQuantity.toIntOrNull()
                        if (length != null && length > 0 && qty != null && qty > 0) {
                            pieces = pieces + Piece(
                                profileTypeId = selectedProfileId,
                                lengthCm = length,
                                quantity = qty
                            )
                            pieceLength = ""
                            pieceQuantity = "1"
                            showAddPieceDialog = false
                        }
                    }
                ) {
                    Text("افزودن")
                }
            },
            dismissButton = {
                TextButton(onClick = { showAddPieceDialog = false }) {
                    Text("انصراف")
                }
            }
        )
    }
}
